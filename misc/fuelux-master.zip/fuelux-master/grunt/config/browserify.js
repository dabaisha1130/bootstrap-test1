module.exports = {
	commonjs: {
		files: {
			'test/commonjs-bundle.js': ['test/commonjs-test.js']
		}
	}
};