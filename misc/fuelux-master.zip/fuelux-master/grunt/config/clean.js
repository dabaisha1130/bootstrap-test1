module.exports = {
	dist: ['dist'],
	zipsrc: ['dist/fuelux'],
	screenshots: ['page-at-timeout-*.jpg']
};