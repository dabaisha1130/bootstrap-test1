BACKLOG
=======

This is a summary of changes under consideration. Please also review the Roadmap at https://github.com/ExactTarget/fuelux/issues?milestone=3&page=1&state=open


Under consideration
-------------------

* **Colorpicker** - Choose a HEX color from possibly a list or a hue/saturation map
* **"SuperTabs"** - Tab navigation with dynamic description/status on each tab